
<template>
  <div>{{ dept }}</div>
</template>

<script>
export default {
  name:'org',
  data () {
    return {
      dept:"开发部"
    };
  },
}

</script>
<style lang='scss' scoped>
</style>