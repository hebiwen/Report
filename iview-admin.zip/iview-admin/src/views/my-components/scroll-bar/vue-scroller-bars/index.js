import scrollBar from './scroll-bar.vue';

export default scrollBar;
