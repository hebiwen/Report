// Exports the "nonbreaking" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/nonbreaking')
//   ES2015:
//     import 'tinymce/plugins/nonbreaking'
require('./plugin.js');
