import eltTransfer from './src/eltTransfer.vue'

eltTransfer.install = function(Vue) {
	Vue.component(eltTransfer.name, eltTransfer);
}

export default eltTransfer;
