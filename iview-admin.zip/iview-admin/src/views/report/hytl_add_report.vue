<style lang="less">
    @import '../../styles/common.less';
    @import '../../styles/draggable-list.less';

    .demo-drawer-footer{
        width: 100%;
        position: absolute;
        bottom: 0;
        left: 0;
        border-top: 1px solid #e8e8e8;
        padding: 10px 16px;
        text-align: right;
        background: #fff;
    }
    .ivu-card-head p{ height:24px;line-height:24px }
</style>

<template>
    <div>
        <Row>
            <Col span="24" class="margin-top-10">
                <Card>
                    <Transfer :data="lstReport" :titles="['可选择行业报告','已选择行业报告']" :target-keys="sltReport" :render-format="renderFormat" :list-style="listStyle"
        :operations="['右移','左移']" @on-change="handleChange"></Transfer>
                    <Page :total="total" :page-size="10" :current="pageIndex" @on-change="changePage" show-total class="margin-top-8" />
                </Card>
            </Col>
        </Row>
        <Drawer title="查询可选择报告" :width="350" v-model="isDrawer">
            <Form :label-width="80">
                <FormItem label="报告名称:">
                    <Input placeholder="请输入报告名称"/>
                </FormItem>
                <FormItem label="报告分类:">
                    <Select></Select>
                </FormItem>
                <FormItem label="报告级别:">
                    <Select></Select>
                </FormItem>
            </Form>
            <div class="demo-drawer-footer">
                <Button style="margin-right: 8px" @click="isDrawer = false">Cancel</Button>
                <Button type="primary" @click="isDrawer = false">Submit</Button>
            </div>
        </Drawer>

</template>

<script>
import util from '../../libs/util';

export default {
    name:'hytlAddReport',
    data(){
        return {
            lstReport:[],
            sltReport:[],
            globalReport:[], 
            total:0,
            pageIndex:1,
            isDrawer:false,
            listStyle: {
                width: "530px",
                height: '500px'
            },    
    mounted () {
        this.getReport(this.pageIndex);
        
    },
    methods:{
        
        getReport(pageIndex){
        var _params = { title:'', category:'', pageIndex:pageIndex };
        this.$http.get("/Api/Report/GetPageReport",{params : _params}).then(result=>{
            if(result.data.code == util.error) return;
            this.total = result.data.total;
            this.pageIndex = result.data.pageIndex;
            let arrReport = JSON.parse(result.data.data);
            let arr = [];
            arrReport.forEach(el => {
                arr.push({ key : el.id,label:el.title,description:el.publishDate })
            })  
            this.lstReport = arr;
            
        }).catch(err=>{
            console.log("get report data error:"+err);
        })
        console.log("分页"+ JSON.stringify(this.sltReport))
    },

    changePage(index){
        this.getReport(index);
    },

    renderFormat(item){
        let title = item.label;
        // let desc = "<span class=fr>"+ item.description +"</span>" ;
        let desc = item.description;
        return title + desc;
    },

    handleChange (nKey) {
        this.sltReport = nKey;
    },
    
    }
}
</script>

