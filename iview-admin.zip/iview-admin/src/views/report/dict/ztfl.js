export default [
    { id:1, title:'马克思主义、列宁主义、毛泽东思想、邓小平理论', sort:'A' },
    { id:2, title:'哲学、宗教', sort:'B' },
    { id:3, title:'社会科学总论', sort:'C' },
    { id:4, title:'政治、法律', sort:'D' },
    { id:5, title:'法律', sort:'DF' },
    { id:6, title:'军事', sort:'E' },
    { id:7, title:'经济', sort:'F' },
    { id:8, title:'文化、科学、教育、体育', sort:'G' },
    { id:9, title:'语言、文字', sort:'H' },
]