<style lang="less">
    @import '../styles/menu.less';
</style>

<template>
    <Menu ref="sideMenu" :active-name="$route.name" :open-names="openNames" :theme="menuTheme" width="auto" @on-select="changeMenu">
        <template v-for="item,index in menuList">
            <MenuItem v-if="item.children.length<=0 " :name="item.children[0].name" :key="'p'+index">
                <Icon :type="item.children[0].icon || item.icon" :size="iconSize" ></Icon>
                <span class="layout-text">{{ itemTitle(item.children[0]) }}</span>
            </MenuItem>

            <Submenu v-if="item.children.length > 0 && roleSecurity.indexOf(item.title)<0 " :name="item.name" :key="item.name">
                <template slot="title" >
                    <Icon :type="item.icon" :size="iconSize"></Icon>
                    <span class="layout-text">{{ itemTitle(item) }} </span>
                </template>
                <template v-for="child,index in item.children">
                    <MenuItem :name="child.name" :key="'c'+index"  v-if="roleSecurity.indexOf(child.title)<0">
                        <Icon :type="child.icon" :size="iconSize" ></Icon>
                        <span class="layout-text">{{ itemTitle(child) }}</span>
                    </MenuItem>
                </template>
            </Submenu>
        </template>
    </Menu>
</template>

<script>
export default {
    name: 'sidebarMenu',
    props: {
        menuList: Array,
        iconSize: Number,
        menuTheme: {
            type: String,
            default: 'dark'
        },
        openNames: {
            type: Array
        },
        roleSecurity:{
            type:Array
        }
    },
    methods: {
        changeMenu (active) {
            this.$emit('on-change', active);
        },
        itemTitle (item) {
            if (typeof item.title === 'object') {
                return this.$t(item.title.i18n);
            } else {
                return item.title;
            }
        }
    },
    updated () {
        this.$nextTick(() => {
            if (this.$refs.sideMenu) {
                this.$refs.sideMenu.updateOpened();
            }
        });
    }

};
</script>
